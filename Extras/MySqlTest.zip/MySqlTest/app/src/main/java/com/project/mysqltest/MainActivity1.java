//package com.project.mysqltest;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.app.ActivityCompat;
//import androidx.loader.app.LoaderManager;
//
//import android.Manifest;
//import android.accessibilityservice.AccessibilityService;
//import android.annotation.SuppressLint;
//import android.app.AlertDialog;
//import android.content.Context;
//import android.content.DialogInterface;
//import android.content.Intent;
//import android.content.Loader;
//import android.content.pm.PackageManager;
//import android.location.Location;
//import android.location.LocationListener;
//import android.location.LocationManager;
//import android.net.ConnectivityManager;
//import android.net.NetworkInfo;
//import android.os.Build;
//import android.os.Bundle;
//import android.os.Looper;
//import android.os.StrictMode;
//import android.provider.Settings;
//import android.util.Log;
//import android.view.View;
//import android.view.inputmethod.InputMethodManager;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.google.android.gms.location.FusedLocationProviderClient;
//import com.google.android.gms.location.LocationCallback;
//import com.google.android.gms.location.LocationRequest;
//import com.google.android.gms.location.LocationResult;
//import com.google.android.gms.location.LocationServices;
//import com.google.android.gms.tasks.OnCompleteListener;
//import com.google.android.gms.tasks.Task;
//
//import java.sql.Connection;
//import java.sql.Driver;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.util.List;
//
//public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {
//
//    EditText username, password;
//    TextView response;
//    Button btn_gpsLocation;
//
//    // initializing FusedLocationProviderClient object
//    FusedLocationProviderClient mFusedLocationClient;
//    int PERMISSION_ID = 44;
//
//    // FOR MYSQL **********
//    private static String myIP = "192.168.0.24";
//    private static String myPORT = "3306";
//    private static String myUSER_NAME = "demo_test";
//    private static String myPASSWORD = "demo_test";
//    //    private static String myClass = "net.sourceforge.jtdc.jdbc.Driver";
//    private static String myClass = "com.project.mysqltest.jdbc.Driver";
//    private static String myDB = "php_test_db";
//    private static String myURL = "jdbc:mysql://" + myIP+":"+myPORT+"/"+myDB;
//
//    private Connection connection=null;
//    // FOR MYSQL **********
//
//    // FOR GPS Location
//    private static final int REQUEST_LOCATION = 1;
//    LocationManager locationManager;
//    String latitude, longitude;
//    public Location location;
//    // FOR GPS Location
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        username = findViewById(R.id.username);
//        password = findViewById(R.id.password);
//        response = findViewById(R.id.response);
//        btn_gpsLocation= findViewById(R.id.btn_gpsLocation);
//
//        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
//
//        // method to get the location
////        getLastLocation();
//
//
//        Log.i("Step 1", "Checking Permission");
//        // New GPS
////        if (Build.VERSION.SDK_INT >=23){
////            if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
////                //Req Location
////                Log.i("Step 2", "Request for permission");
////                requestPermissions(new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, 1);
////            }
////            else{
////                //Req Location Permission
////                Log.i("Step 3", "Permission Granted");
////                StartGPS();
////            }
////        }else{
////            // Start the location services
////            Log.i("Step 4", "BUILD version different");
////            StartGPS();
////        }
//
////        btn_gpsLocation.callOnClick()
//
//        // FOR GPS Location
////        ActivityCompat.requestPermissions( this,
////                new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
//        // FOR GPS Location
//
//
////        // FOR MYSQL **********
////        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
////        StrictMode.setThreadPolicy(policy);
////
////        try {
////            Class.forName(myClass);
////            connection = DriverManager.getConnection(myURL, myUSER_NAME, myPASSWORD);
////        } catch (ClassNotFoundException | SQLException e) {
////            Log.i("MYSQL", "Error: 1. "+ e.toString());
////        }
////        // FOR MYSQL **********
//
//
//
//
////        //Check if a Loader is running, if it is, reconnect to it
////        if(getSupportLoaderManager().getLoader(0)!=null){
////            getSupportLoaderManager().initLoader(0,null,this);
////        }
//
//    }
//
//
//
//
//    public void btn_login(View view) {
//        String user_id = username.getText().toString();
//        String user_pwd = password.getText().toString();
//
//
//        // New GPS
//        Log.i("Say Something", "FFFFFFFF");
////        GPSLocation gpsLocation = new GPSLocation();
////        gpsLocation.getLastLocation();
//        getLastLocation();
//
//        // FOR GPS Location
////        LocationManager nManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
////        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
////            OnGPS();
////        } else {
////            getLocation();
////        }
//        // FOR GPS Location
//
//        // Hide the keyboard when the button is pushed.
//        //        InputMethodManager inputManager = (InputMethodManager)
//        //                getSystemService(Context.INPUT_METHOD_SERVICE);
//        //        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
//        //                InputMethodManager.HIDE_NOT_ALWAYS);
//
///*
//        // Check the status of the network connection.
//        ConnectivityManager connMgr = (ConnectivityManager)
//                getSystemService(Context.CONNECTIVITY_SERVICE);
//        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
//
//        // If the network is active and the search field is not empty,
//        // add the search term to the arguments Bundle and start the loader.
//        if (networkInfo != null && networkInfo.isConnected() && user_id.length()!=0 && user_pwd.length()!=0) {
//            response.setText("");
//            response.setText(R.string.loading);
//            Bundle queryBundle = new Bundle();
//            queryBundle.putString("queryUserName", user_id);
//            queryBundle.putString("queryUserPassword", user_pwd);
//            getSupportLoaderManager().restartLoader(0, queryBundle, this);
//        }
//        // Otherwise update the TextView to tell the user there is no connection or no search term.
//        else {
//            if (user_id.length() == 0) {
//                response.setText("Invalid User Name");
////                response.setText(R.string.no_search_term);
//            } else {
//                response.setText("No Network");
////                mTitleText.setText(R.string.no_network);
//            }
//        }
//
//*/
//
////        // FOR MYSQL **********
////        if(connection!=null){
////            Statement statement = null;
////            try {
////                statement = connection.createStatement();
////                ResultSet resultSet = statement.executeQuery("Select * FROM tbl_login_details " +
////                        " where user_id = '" + user_id + "' and pwd = '" + user_pwd +  "';");
////
////                response.setText("From MySQL: Welcome" + resultSet.getString(1));
////            } catch (SQLException throwables) {
//////                throwables.printStackTrace();
////                Log.i("MYSQL", "Error: 2. "+ throwables.toString());
////            }
////        }else {
////            response.setText("From MySQL: No connection" );
////        }
////        // FOR MYSQL **********
//    }
//
////    @Override
////    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
////        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
////        switch (requestCode){
////            case 1:
////                if (grantResults[0]== PackageManager.PERMISSION_GRANTED){
////                    StartGPS();
////                }else{
////                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
////                }
////
////        }
////    }
//
//    void StartGPS(){
//        Intent intent = new Intent(this, GPSLocation.class);
//        startActivity(intent);
////        GPSLocation gpsLocation = new GPSLocation();
////        gpsLocation.getLocationUpdates();
//    }
//
//
//    /**
//     * The LoaderManager calls this method when the loader is created.
//     *
//     * @param id ID integer to id   entify the instance of the loader.
//     * @param args The bundle that contains the search parameter.
//     * @return Returns a new BookLoader containing the search term.
//     */
//    @Override
//    public androidx.loader.content.Loader<String> onCreateLoader(int id, Bundle args){
////    public androidx.loader.content.Loader<String> onCreateLoader(int id, Bundle args) {
//        return new BookLoader(this, args.getString("queryUserName"), args.getString("queryUserPassword"));
//    }
//
//    @Override
//    public void onLoadFinished(@NonNull androidx.loader.content.Loader<String> loader, String data) {
//        response.setText("Result: " + data);
//    }
//
//    @Override
//    public void onLoaderReset(@NonNull androidx.loader.content.Loader<String> loader) {
//
//    }
//
//    /**
//     * Called when the data has been loaded. Gets the desired information from
//     * the JSON and updates the Views.
//     *
//     * @param loader The loader that has finished.
//     * @param data The JSON response from the Books API.
//     */
//
//    public void onLoadFinished(Loader<String> loader, String data) {
//        try {
//            response.setText(data);
//
//        } catch (Exception e){
//            // If onPostExecute does not receive a proper JSON string, update the UI to show failed results.
//            response.setText("No Result");
////            mAuthorText.setText("");
//            e.printStackTrace();
//        }
//
//
//    }
//
//    /**
//     * In this case there are no variables to clean up when the loader is reset.
//     *
//     * @param loader The loader that was reset.
//     */
//
//    public void onLoaderReset(Loader<String> loader) {}
//
//    private void OnGPS() {
//        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("Yes", new  DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
//            }
//        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                dialog.cancel();
//            }
//        });
//        final AlertDialog alertDialog = builder.create();
//        alertDialog.show();
//    }
//
//    private void getLocation() {
//        if (ActivityCompat.checkSelfPermission(
//                MainActivity.this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
//                MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
//        } else {
//
//            try {
//                location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
//                Toast.makeText(this, "Found something.", Toast.LENGTH_SHORT).show();
//            } catch (SecurityException e) {
////                dialogGPS(this.getContext()); // lets the user know there is a problem with the gps
//                Toast.makeText(this, "STEP 1: Unable to find location.", Toast.LENGTH_SHORT).show();
//            }
//
//            LocationManager nManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
////            Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
//            LocationManager mLocationManager;
//            LocationListener listener;
////            nManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0 ,  listener );
//            Location locationGPS = getLastKnownCoarseLocation();
////            Location locationGPS =
//            if (locationGPS != null) {
//                double lat = locationGPS.getLatitude();
//                double longi = locationGPS.getLongitude();
//                latitude = String.valueOf(lat);
//                longitude = String.valueOf(longi);
//                Toast.makeText(this,"Your Location: " + "\n" + "Latitude: " + latitude + "\n" + "Longitude: " + longitude, Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(this, "Unable to find location.", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }
//
////    private Location getLastKnownLocation() {
////        LocationManager mLocationManager;
////        mLocationManager = (LocationManager)getApplicationContext().getSystemService(LOCATION_SERVICE);
////        List<String> providers = mLocationManager.getProviders(true);
////        Location bestLocation = null;
////        for (String provider : providers) {
////            Location l = mLocationManager.getLastKnownLocation(provider);
////            if (l == null) {
////                continue;
////            }
////            if (bestLocation == null || l.getAccuracy() < bestLocation.getAccuracy()) {
////                // Found best last known location: %s", l);
////                bestLocation = l;
////            }
////        }
////        return bestLocation;
////    }
//
//
//    public Location getLastKnownCoarseLocation () {
//        AccessibilityService activity = null;
//        assert activity != null;
//        LocationManager locationManager = (LocationManager) activity.getSystemService(Context.LOCATION_SERVICE);
//        try {
//            // Walk through each enabled location provider and return the first found, last-known location
//            for (String thisLocProvider : locationManager.getProviders(true)) {
//                Location lastKnown = locationManager.getLastKnownLocation(thisLocProvider);
//
//                if (lastKnown != null) {
//                    return lastKnown;
//                }
//            }
//        } catch(SecurityException exception) {
//
//        }
//        // Always possible there's no means to determine location
//        return null;
//    }
//
////    // NEW WORKING GPS LOCATION
////    @SuppressLint("MissingPermission")
////    private void getLastLocation() {
////        // check if permissions are given
////        if (checkPermissions()) {
////            // check if location is enabled
////            if (isLocationEnabled()) {
////                // getting last location from FusedLocationClient object
////                mFusedLocationClient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
////                    @Override
////                    public void onComplete(@NonNull Task<Location> task){
////                        Location location = task.getResult();
////                        if (location == null) {
////                            requestNewLocationData();
////                        }
////                        else {
////                            String result = "\nLat: " + location.getLatitude() + "\nLongitude: " + location.getLongitude();
////                            Log.i("RESPONSE **** ", result);
////                        }
////                    }
////                });
////            }
////            else {
////                Toast.makeText(this,"Please turn on"+ " your location...",Toast.LENGTH_LONG).show();
////
////                Intent intent = new Intent( Settings.ACTION_LOCATION_SOURCE_SETTINGS);
////                startActivity(intent);
////            }
////        }
////        else {
////            // if permissions aren't available, request for permissions
////            requestPermissions();
////        }
////    }
////
////    @SuppressLint("MissingPermission")
////    private void requestNewLocationData() {
////        // Initializing LocationRequest object with appropriate methods
////        LocationRequest mLocationRequest = new LocationRequest();
////        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
////        mLocationRequest.setInterval(5);
////        mLocationRequest.setFastestInterval(0);
////        mLocationRequest.setNumUpdates(1);
////
////        // setting LocationRequest on FusedLocationClient
////        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
////        mFusedLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, Looper.myLooper());
////    }
////
////    private LocationCallback mLocationCallback = new LocationCallback() {
////        @Override
////        public void onLocationResult(LocationResult locationResult) {
////            Location mLastLocation = locationResult.getLastLocation();
////            String result = "\nSTEP 2: Lat: " + location.getLatitude() + "\nLongitude: " + location.getLongitude();
////            Log.i("RESPONSE **** ", result);
////        }
////    };
////
////    // method to check for permissions
////    private boolean checkPermissions() {
////        return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
////                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
////    }
////
////    // method to request for the permissions
////    private void requestPermissions() {
////        ActivityCompat.requestPermissions(this, new String[] {
////                        Manifest.permission.ACCESS_COARSE_LOCATION,
////                        Manifest.permission.ACCESS_FINE_LOCATION },
////                PERMISSION_ID);
////    }
////
////    // method to check if location is enabled
////    private boolean isLocationEnabled() {
////        LocationManager locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
////        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
////                || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
////    }
////
////    // If everything is alright then
////    @Override
////    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
////        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
////        if (requestCode == PERMISSION_ID) {
////            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
////                getLastLocation();
////            }
////        }
////    }
////
////    @Override
////    public void onResume() {
////        super.onResume();
////        if (checkPermissions()) {
////            getLastLocation();
////        }
////    }
//}