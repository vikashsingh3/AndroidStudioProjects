package com.project.mysqltest;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;

class LoadingProgressBar {

    Activity activity;
    AlertDialog alertDialog;

    LoadingProgressBar(Activity myActivity){
        activity = myActivity;
    }

    void StartProgressBar(){
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        LayoutInflater layoutInflater = activity.getLayoutInflater();
        builder.setView(layoutInflater.inflate(R.layout.layout_progress_bar, null));
        builder.setCancelable(false);

        alertDialog = builder.create();
        alertDialog.show();
    }

    void CancelProgressBar(){
        alertDialog.dismiss();
    }
}
